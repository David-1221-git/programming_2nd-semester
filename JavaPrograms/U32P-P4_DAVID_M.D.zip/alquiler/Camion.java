package alquiler;
public class Camion extends FurgonetaCarga {
    public double precioFijoCamion = 40.00;

    public Camion() {
        super();
    }

    public Camion(String matricula, int diasAlquiler) {
        super(matricula, diasAlquiler);
    }

    public Camion(String matricula, int diasAlquiler, double pma) {
        super(matricula, diasAlquiler, pma);
    }

    @Override
    public double calcularPrecio() {
        double precioFurgoneta = super.calcularPrecio();
        return precioFurgoneta + precioFijoCamion;
    }

    @Override
    public String informacion() {
        return super.informacion().replace("Furgoneta", "Camion");
    }
}