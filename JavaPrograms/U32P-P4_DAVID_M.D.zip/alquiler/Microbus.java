package alquiler;
public class Microbus extends Coche {
    public double precioFijoPorPlaza = 2.00;

    public Microbus() {
        super();
    }

    public Microbus(String matricula, int diasAlquiler) {
        super(matricula, diasAlquiler);
    }

    public Microbus(String matricula, int diasAlquiler, int plazas) {
        super(matricula, diasAlquiler, plazas);
    }

    @Override
    public double calcularPrecio() {
        double precioCoche = super.calcularPrecio();
        double precioFijo = precioFijoPorPlaza * plazas;
        return precioCoche + precioFijo;
    }

    @Override
    public String informacion() {
        return super.informacion().replace("Coche", "Microbus");
    }
}