package alquiler;
public class FurgonetaCarga extends Vehiculo {
    public double pma;
    public double precioPorPMA = 20.00;

    public FurgonetaCarga() {
        super();
        this.pma = 0;
    }

    public FurgonetaCarga(String matricula, int diasAlquiler) {
        super(matricula, diasAlquiler);
        this.pma = 0;
    }

    public FurgonetaCarga(String matricula, int diasAlquiler, double pma) {
        super(matricula, diasAlquiler);
        this.pma = pma;
    }

    public void setPma(double pma) {
        this.pma = pma;
    }

    public double getPma() {
        return pma;
    }

    @Override
    public double calcularPrecio() {
        double precioBase = super.calcularPrecio();
        double precioPma = precioPorPMA * pma;
        return precioBase + precioPma;
    }

    @Override
    public String informacion() {
        return super.informacion() + " | Tipo: Furgoneta | PMA: " + pma;
    }
}