package alquiler;
public class Vehiculo {
    public String matricula;
    public int diasAlquiler;
    public double precioBaseDiario = 50.00;

    public Vehiculo() {
        this.matricula = "";
        this.diasAlquiler = 0;
    }

    public Vehiculo(String matricula, int diasAlquiler) {
        this.matricula = matricula;
        this.diasAlquiler = diasAlquiler;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setDiasAlquiler(int dias) {
        this.diasAlquiler = dias;
    }

    public int getDiasAlquiler() {
        return diasAlquiler;
    }

    public double calcularPrecio() {
        return precioBaseDiario * diasAlquiler;
    }

    public String informacion() {
        return "Matricula: " + matricula + " | Dias: " + diasAlquiler;
    }
}