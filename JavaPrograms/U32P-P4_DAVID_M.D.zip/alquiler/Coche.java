package alquiler;
public class Coche extends Vehiculo {
    public int plazas;
    public double precioPorPlazaDia = 1.50;

    public Coche() {
        super();
        this.plazas = 0;
    }

    public Coche(String matricula, int diasAlquiler) {
        super(matricula, diasAlquiler);
        this.plazas = 0;
    }

    public Coche(String matricula, int diasAlquiler, int plazas) {
        super(matricula, diasAlquiler);
        this.plazas = plazas;
    }

    public void setPlazas(int plazas) {
        this.plazas = plazas;
    }

    public int getPlazas() {
        return plazas;
    }

    @Override
    public double calcularPrecio() {
        double precioBase = super.calcularPrecio();
        double precioPlazas = precioPorPlazaDia * plazas * diasAlquiler;
        return precioBase + precioPlazas;
    }

    @Override
    public String informacion() {
        return super.informacion() + " | Tipo: Coche | Plazas: " + plazas;
    }
}